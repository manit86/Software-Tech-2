move_coutn = 0

def main():
    global move_coutn
    n = eval(input("Enter number of disks: "))

    move_coutn = 0

    moveDisks(n, 'A', 'B', 'C')

    print("The moves are:")
    print("The number of moves are: ", move_coutn)

#    The function for finding the solution to move n disks
# from fromTower to toTower with auxTower
def moveDisks(n, fromTower, toTower, auxTower):
    global move_coutn
    if n == 1: # Stopping condition
        move_coutn += 1
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        move_coutn +=1
        moveDisks(n - 1, auxTower, toTower, fromTower)

main() # Call the main function
