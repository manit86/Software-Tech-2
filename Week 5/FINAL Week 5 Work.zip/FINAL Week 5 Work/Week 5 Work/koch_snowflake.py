from turtle import *

def koch(length, order):

    if order == 0:
        forward(length)

    else:
        length /= 3

        koch(length, order-1)
        left(60)

        koch(length, order-1)
        right(120)

        koch(length, order-1)
        left(60)

        koch(length, order-1)


def snowflake(length, order):

    for i in range(3):
        koch(length, order)
        right(120)
    
speed(0)

order = int(input("Enter Order: "))        

snowflake(300, order)

done()